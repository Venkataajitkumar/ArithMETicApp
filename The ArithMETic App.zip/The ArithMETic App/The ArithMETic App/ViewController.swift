//
//  ViewController.swift
//  The ArithMETic App
//
//  Created by student on 2/14/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    var input:String = " "
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
      return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        input = pickerData[row]
    }
    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        // Do any additional setup after loading the view, typically from a nib.
//    }
    
    
    @IBOutlet weak var weight: UITextField!
    
    @IBOutlet weak var exercisetime: UITextField!
    
    @IBOutlet weak var energyconsumed: UILabel!
    
    @IBOutlet weak var timetolose1pound: UILabel!
    @IBAction func calculate(_ sender: Any) {
        if weight.text != "" || exercisetime.text != ""{
            if let w = Double(weight.text!), let et = Double(exercisetime.text!){
                let consumed: Double = ExerciseCoach.energyConsumed(during: input, weight: w, time: et)
                energyconsumed.text = String(format:"%.1f cal", consumed)
                let time_p:Double = ExerciseCoach.timeToLose1Pound(during: input, weight: w)
                timetolose1pound.text = String(format:"%.1f minutes", time_p)
            }
            else{
                let alertController = UIAlertController(title: "", message: "Invalid details",
                                                        preferredStyle: .alert)
                let action = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(action)
                self.show(alertController, sender: nil)
            }
        }
        else{
            let alertController = UIAlertController(title: "", message: "Invalid details",
                                                    preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(action)
            self.show(alertController, sender: nil)
        }
    }
    
    @IBAction func clear(_ sender: Any) {
        //UIActivity.text = nil
        weight.text = nil
        exercisetime.text = nil
        energyconsumed.text = String(0)
        timetolose1pound.text = String(0)
    }
    
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    var pickerData: [String] = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerData = ["Bicycling" , "Jumping rope" ,"Running - slow" , "Running-fast" ,"Tennis" ,"Swimming"]
    
}

struct ExerciseCoach {
    static var pair:[String:Double] = ["Bicycling":8.0, "Jumping rope":12.3, "Running - slow":9.8, "Running - fast":23.0, "Tennis":8.0, "Swimming":5.8]
    static func energyConsumed(during:String, weight:Double, time:Double) -> Double {
        var energy:Double = 0
        if let m = pair[during] {
            energy = m * 3.5 * ((weight/2.2) / 200) * time
        }
         return energy
    }
    static func timeToLose1Pound(during:String, weight:Double) -> Double{
        var timeLose:Double = 0
        if let m = pair[during] {
            timeLose = 3500 / (m * 3.5 * (weight/2.2) / 200)
        }
        return timeLose
    }
}
}
